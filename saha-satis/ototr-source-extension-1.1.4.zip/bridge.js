// Only visible source fields are read. No credentials, cookies, or database writes.
let gesture=0,batch=null;
document.addEventListener('click',e=>{if(e.isTrusted&&e.target.closest('[data-source-import]'))gesture=Date.now()},true);
const reply=(id,value)=>window.postMessage({channel:'ototr-source-response',id,...value},location.origin);
async function runBatch(job,items){
 let reason='complete';
 try{
  for(const item of items){
   if(job.cancelled){reason='cancelled';break}
   reply(job.id,{batchEvent:'progress',itemId:item.id});
   const result=await chrome.runtime.sendMessage({action:'read',url:item.url});
   reply(job.id,{batchEvent:'item',itemId:item.id,...result});
   if(!result||result.error||result.halt){reason='blocked';break}
   if(job.cancelled){reason='cancelled';break}
   if(item!==items[items.length-1])await new Promise(resolve=>setTimeout(resolve,3000));
  }
 }catch{reason='error';reply(job.id,{batchEvent:'error',error:'Chrome bağlantısı kesildi. Yeni mağaza açılmadı; tamamlanan sonuçları inceleyebilirsiniz.'})}
 finally{if(job.cancelled&&reason==='complete')reason='cancelled';batch=null;reply(job.id,{batchEvent:'done',reason})}
}
window.addEventListener('message',async e=>{
 if(e.source!==window||e.origin!==location.origin||!location.pathname.startsWith('/Ototr/saha-satis/'))return;
 const m=e.data;if(m?.channel!=='ototr-source-request'||typeof m.id!=='string'||m.id.length>80)return;
 if(m.action==='ping'){reply(m.id,{ready:true,version:chrome.runtime.getManifest().version,batchSupported:true});return}
 if(m.action==='batch-stop'){if(batch?.id===m.id)batch.cancelled=true;return}
 if(!['read','batch'].includes(m.action)||!gesture||Date.now()-gesture>2000)return;gesture=0;
 if(batch){reply(m.id,{error:'Toplu kontrol sürüyor. Önce mevcut işlemi durdurun.'});return}
 if(m.action==='batch'){
  const items=m.items;
  const validUrl=value=>{try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&/^[a-z0-9-]+\.sahibinden\.com$/.test(u.hostname)&&!['www','secure','banaozel','yardim','image','m'].includes(u.hostname.split('.')[0])}catch{return false}};
  if(!Array.isArray(items)||!items.length||items.length>10||items.some(x=>!x||typeof x.id!=='string'||!x.id||x.id.length>100||typeof x.url!=='string'||!validUrl(x.url))||new Set(items.map(x=>x.id)).size!==items.length||new Set(items.map(x=>new URL(x.url).origin)).size!==items.length){reply(m.id,{error:'Tek seferde en fazla 10 farklı mağaza seçin.'});return}
  batch={id:m.id,cancelled:false};void runBatch(batch,items.map(x=>({id:x.id,url:x.url})));return;
 }
 try{const r=await chrome.runtime.sendMessage({action:'read',url:m.url});reply(m.id,r)}catch{reply(m.id,{error:'Chrome bağlantısı kesildi. ERP sayfasını yenileyin.'})}
});
