import {shopUrl,readStorePage} from './parser.js';
let busy=false;
const allowed=url=>{try{const u=new URL(url);return u.origin==='https://samivolkan.github.io'&&u.pathname.startsWith('/Ototr/saha-satis/')}catch{return false}};
async function loaded(id){const started=Date.now();while(Date.now()-started<25000){const t=await chrome.tabs.get(id);if(t.status==='complete')return;await new Promise(r=>setTimeout(r,250))}throw Error('Mağaza sayfası zamanında açılmadı.')}
async function run(url){const root=shopUrl(url);if(!root)return {error:'https://magaza.sahibinden.com/ biçiminde mağaza bağlantısı girin.'};
 const owned=new Set();
 const read=async target=>{
  const open=(await chrome.tabs.query({url:new URL(root).origin+'/*'})).find(t=>{try{return new URL(t.url).pathname===new URL(target).pathname}catch{return false}});
  const id=open?.id??(await chrome.tabs.create({url:target,active:true})).id;
  if(!open)owned.add(id);
  await loaded(id);const t=await chrome.tabs.get(id);
  if(!t.url||!/^https:\/\/([a-z0-9-]+\.)?sahibinden\.com\//.test(t.url)||t.url.startsWith('https://secure.'))throw Error('Bu sayfa giriş/erişim doğrulaması istiyor. Açık Sahibinden sekmesinde tamamlayıp tekrar deneyin.');
  const injection=(await chrome.scripting.executeScript({target:{tabId:id},func:readStorePage}))[0];
  const value=injection?.result;
  if(value?.readError)throw Error(value.readError);
  if(!value)throw Error('Mağaza sayfası okunamadı. Sayfanın tamamen açıldığını kontrol edin ve tekrar deneyin.');
  if(shopUrl(value.storeUrl)!==root)throw Error('Okunan mağaza ('+(shopUrl(value.storeUrl)||'tanımlanamadı')+') girdiğiniz mağaza ile eşleşmiyor.');
  if(owned.has(id)){await chrome.tabs.remove(id);owned.delete(id)}
  return value;
 };
 try{
  const entry=new URL(url);const start=entry.origin+entry.pathname+entry.search;
  const home=await read(start);
  const result={name:home.name.toLocaleUpperCase('tr-TR'),contacts:home.contacts||[],city:home.city||'',district:home.district||'',neighborhood:home.neighborhood||'',address:'',sources:[{url:start,label:'Sahibinden mağaza',date:new Date().toISOString().slice(0,10)}],warnings:[]};
  if(home.storePhone&&!result.contacts.some(c=>c.phone===home.storePhone))result.contacts.push({name:'',phone:home.storePhone,role:'İşletme telefonu'});
  let blocked=false;
  if(home.teamUrl&&new URL(home.teamUrl).pathname.replace(/\/$/,'')!==entry.pathname.replace(/\/$/,'')&&new URL(home.teamUrl).origin===new URL(root).origin){try{const team=await read(home.teamUrl);result.contacts=[...team.contacts,...result.contacts.filter(c=>!team.contacts.some(x=>x.phone&&x.phone===c.phone))];result.sources.push({url:team.url,label:'Sahibinden Ekibimiz',date:new Date().toISOString().slice(0,10)})}catch(e){blocked=true;result.warnings.push('Ekip bilgileri alınamadı: '+e.message)}}
  let listingUrl=home.listingUrl;
  // Team pages often omit listings. Read this same store's home page once.
  if(!result.neighborhood&&!listingUrl&&!blocked&&entry.pathname.replace(/\/$/,'')!==''){try{const store=await read(root);listingUrl=store.listingUrl;if(store.neighborhood){Object.assign(result,{city:store.city||'',district:store.district||'',neighborhood:store.neighborhood});result.sources.push({url:root,label:'Sahibinden mağaza konumu',date:new Date().toISOString().slice(0,10)})}}catch(e){blocked=true;result.warnings.push('Mağaza konumu alınamadı: '+e.message)}}
  if(!result.neighborhood&&listingUrl&&!blocked){try{const listing=await read(listingUrl);Object.assign(result,{city:listing.city||'',district:listing.district||'',neighborhood:listing.neighborhood||''});result.sources.push({url:listing.url,label:'Sahibinden ilan konumu (işyeri adresi doğrulanmadı)',date:new Date().toISOString().slice(0,10)})}catch(e){result.warnings.push('İlan konumu alınamadı: '+e.message)}}
  if(!result.neighborhood)result.warnings.push('Mahalle kaynakta bulunamadı. Mağaza veya ona ait ilandaki konumu kontrol edip mahalleyi elle seçebilirsiniz.');
  result.warnings.push('Okunabilen bilgiler aşağıdadır. İlan mahallesi işyeri adresini doğrulamaz; açık adres tahmin edilmez.');
  if(!result.contacts.some(c=>/^galeri sahibi$/i.test(c.role)))result.warnings.push('Kaynakta açıkça Galeri Sahibi olarak belirtilen kişi bulunamadı.');
  return {draft:result};
 }catch(e){return {error:e.message||'Bilgiler okunamadı. Mağaza sekmesini kontrol edin.'}}
 // Existing tabs are never closed. Failed/challenge tabs remain for user action; no automatic retry.
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
 if(sender.id!==chrome.runtime.id||!allowed(sender.url)||sender.frameId!==0||m?.action!=='read')return;
 if(busy){reply({error:'Bir mağaza aktarımı zaten sürüyor.'});return}busy=true;
 run(m.url).then(reply).catch(()=>reply({error:'Aktarım tamamlanamadı.'})).finally(()=>{busy=false});return true;
});
