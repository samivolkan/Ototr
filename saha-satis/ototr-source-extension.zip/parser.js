export function shopUrl(value){
 try{const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||! /^[a-z0-9-]+\.sahibinden\.com$/.test(u.hostname)||['www','secure','banaozel','yardim','image','m'].includes(u.hostname.split('.')[0]))return '';return u.origin+'/'}catch{return ''}
}
// Executed in an isolated world. Only visible store/team/location DOM is returned.
export async function readStorePage(){
 const text=e=>e?.innerText?.trim()||'';
 const visible=e=>!!e&&!!e.getClientRects().length;
 if(location.hostname==='secure.sahibinden.com'||document.querySelector('input[type=password]')||/access denied|just a moment|robot doğrulama|erişim engellendi/i.test(document.title+' '+text(document.querySelector('h1'))))throw Error('Giriş veya erişim doğrulaması gerekiyor. Sahibinden sekmesinde tamamlayın; engel aşılmaz.');
 for(const e of [...document.querySelectorAll('.contact-info .phone-trigger,.consultant .phone-trigger')].filter(visible).slice(0,12)){
  if(text(e)==='Telefonu Göster')e.click();
 }
 await new Promise(r=>setTimeout(r,350));
 const phone=s=>{let n=s.replace(/\D/g,'');if(n.startsWith('90')&&n.length===12)n=n.slice(2);if(n.length===10)n='0'+n;return /^0[2-5]\d{9}$/.test(n)?n:''};
 const contacts=[...document.querySelectorAll('.consultant')].filter(visible).slice(0,12).map(c=>({name:text(c.querySelector('.name')),role:text(c.querySelector('.title')),phone:phone(text(c.querySelector('.phone-trigger')))})).filter(c=>c.name||c.phone);
 const storePhone=phone(text(document.querySelector('.contact-info .phone-trigger')));
 const links=[...document.querySelectorAll('a[href]')].filter(visible);
 const origin=location.origin;
 const onStore=/^[a-z0-9-]+\.sahibinden\.com$/.test(location.hostname)&&!['www','secure','banaozel','yardim','image','m'].includes(location.hostname.split('.')[0]);
 const locationParts=[...document.querySelectorAll('.classifiedLocation a')].map(text);
 const store=links.find(a=>a.matches('.store-logo'))||links.find(a=>a.querySelector('img')&&/^https:\/\/[a-z0-9-]+\.sahibinden\.com\/?$/.test(a.href)&&!a.href.includes('www.sahibinden.com'));
 const name=text(document.querySelector('.store-name'))||store?.getAttribute('title')||store?.querySelector('img')?.alt||'';
 const result={url:location.href.split('?')[0],name,storeUrl:onStore?origin+'/':store?.href||'',contacts,storePhone,city:locationParts[0]||'',district:locationParts[1]||'',neighborhood:(locationParts[2]||'').replace(/\s+(Mah\.|Mh\.|Mahallesi)$/i,''),teamUrl:links.find(a=>text(a)==='Ekibimiz')?.href||'',listingUrl:links.find(a=>/^https:\/\/(www\.)?sahibinden\.com\/ilan\/vasita-/.test(a.href))?.href||''};
 if(!name&&!locationParts.length)throw Error('İşletme alanları okunamadı. Giriş/erişim ekranını kontrol edin.');
 return result;
}
