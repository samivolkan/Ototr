import {shopUrl,readStorePage} from './parser.js';
let busy=false;
const allowed=url=>{try{const u=new URL(url);return u.origin==='https://samivolkan.github.io'&&u.pathname.startsWith('/Ototr/saha-satis/')}catch{return false}};
async function loaded(id){const started=Date.now();while(Date.now()-started<25000){const t=await chrome.tabs.get(id);if(t.status==='complete')return;await new Promise(r=>setTimeout(r,250))}throw Error('Mağaza sayfası zamanında açılmadı.')}
async function run(url){const root=shopUrl(url);if(!root)throw Error('https://magaza.sahibinden.com/ biçiminde mağaza bağlantısı girin.');let id;
 try{
  id=(await chrome.tabs.create({url:root,active:true})).id;await loaded(id);
  const read=async()=>{const t=await chrome.tabs.get(id);if(!t.url||!/^https:\/\/([a-z0-9-]+\.)?sahibinden\.com\//.test(t.url)||t.url.startsWith('https://secure.'))throw Error('Sahibinden giriş/erişim doğrulaması istiyor. Açık mağaza sekmesinde giriş yapıp ERP’den tekrar deneyin.');return (await chrome.scripting.executeScript({target:{tabId:id},func:readStorePage}))[0].result};
  const home=await read();if(shopUrl(home.storeUrl)!==root)throw Error('Mağaza kimliği bağlantıyla eşleşmedi.');
  const result={name:home.name.toLocaleUpperCase('tr-TR'),contacts:[],city:'',district:'',neighborhood:'',address:'',sources:[{url:root,label:'Sahibinden mağaza',date:new Date().toISOString().slice(0,10)}],warnings:[]};
  if(home.teamUrl&&new URL(home.teamUrl).origin===new URL(root).origin){await chrome.tabs.update(id,{url:home.teamUrl});await loaded(id);const team=await read();if(shopUrl(team.storeUrl)!==root)throw Error('Ekip sayfası başka bir mağazaya ait.');result.contacts=team.contacts;result.sources.push({url:team.url,label:'Sahibinden Ekibimiz',date:new Date().toISOString().slice(0,10)})}
  if(home.storePhone&&!result.contacts.some(c=>c.phone===home.storePhone))result.contacts.push({name:'',phone:home.storePhone,role:'İşletme telefonu'});
  if(home.listingUrl){await chrome.tabs.update(id,{url:home.listingUrl});await loaded(id);const listing=await read();if(shopUrl(listing.storeUrl)!==root)throw Error('İlanın mağaza kimliği eşleşmedi.');Object.assign(result,{city:listing.city,district:listing.district,neighborhood:listing.neighborhood});result.sources.push({url:listing.url,label:'Sahibinden ilan konumu (işyeri adresi doğrulanmadı)',date:new Date().toISOString().slice(0,10)})}
  result.warnings.push('Mahalle ilan konumudur; açık işyeri adresi doğrulanmadı. Mevcut adresiniz korunur.');
  if(!result.contacts.some(c=>/^galeri sahibi$/i.test(c.role)))result.warnings.push('Kaynakta açıkça Galeri Sahibi olarak belirtilen kişi bulunamadı.');
  await chrome.tabs.remove(id);id=null;return {draft:result};
 }catch(e){return {error:e.message||'Bilgiler okunamadı. Mağaza sekmesini kontrol edin.'}}
 // On login/challenge/error leave the source tab for user action. Never auto retry.
}
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
 if(sender.id!==chrome.runtime.id||!allowed(sender.url)||sender.frameId!==0||m?.action!=='read')return;
 if(busy){reply({error:'Bir mağaza aktarımı zaten sürüyor.'});return}busy=true;
 run(m.url).then(reply).catch(()=>reply({error:'Aktarım tamamlanamadı.'})).finally(()=>{busy=false});return true;
});
