// No credentials, storage, clipboard, hidden API or database access.
let gesture=0;
document.addEventListener('click',e=>{if(e.isTrusted&&e.target.closest('[data-source-import]'))gesture=Date.now()},true);
window.addEventListener('message',async e=>{
 if(e.source!==window||e.origin!==location.origin||!location.pathname.startsWith('/Ototr/saha-satis/'))return;
 const m=e.data;if(m?.channel!=='ototr-source-request'||typeof m.id!=='string'||m.id.length>80)return;
 if(m.action==='ping'){window.postMessage({channel:'ototr-source-response',id:m.id,ready:true,version:chrome.runtime.getManifest().version},location.origin);return}
 if(m.action!=='read'||Date.now()-gesture>2000)return;gesture=0;
 try{const r=await chrome.runtime.sendMessage({action:'read',url:m.url});window.postMessage({channel:'ototr-source-response',id:m.id,...r},location.origin)}catch{window.postMessage({channel:'ototr-source-response',id:m.id,error:'Chrome bağlantısı kesildi. ERP sayfasını yenileyin.'},location.origin)}
});
